
package com.spring.error.errorchecker;

public interface CommentErrorChecker {

}
