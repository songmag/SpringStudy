package com.spring.error.errorchecker;

import org.springframework.stereotype.Component;

@Component
public class CommentErrorCheckerImpl implements CommentErrorChecker {

}
