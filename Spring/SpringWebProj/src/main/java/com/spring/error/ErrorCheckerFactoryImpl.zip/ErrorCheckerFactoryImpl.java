package com.spring.error;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.spring.error.errorchecker.CommentErrorCheckerImpl;
import com.spring.error.errorchecker.MenuErrorCheckerImpl;
import com.spring.error.errorchecker.PostErrorCheckerImpl;
import com.spring.error.errorchecker.UserErrorCheckerImpl;

@Component
public class ErrorCheckerFactoryImpl implements ErrorCheckerFactory{

	@Autowired
	ApplicationContext application;
	@Override
	public Object errorChecker(Object[] dto, Class[] dto_class, String errorCode) {
		Class checker = null;
		System.out.println(dto_class[0].getName());
		if(!dto_class[0].getName().equals(dto[0].getClass().getName()))
		{
			System.out.println("Class Miss Match");
			return null;
		}
		if(dto_class[0].getName().equals("com.spring.model.dto.UserDTO"))
		{
			checker = UserErrorCheckerImpl.class;
		}
		else if(dto_class[0].getName().equals("com.spring.model.dto.MenuDTO"))
		{
			checker = MenuErrorCheckerImpl.class;
		}
		else if(dto_class[0].getName().equals("com.spring.model.dto.PostDTO"))
		{
			checker = PostErrorCheckerImpl.class;
		}
		else if(dto_class[0].getName().equals("com.spring.model.dto.CommentDTO"))
		{
			checker = CommentErrorCheckerImpl.class;
		}
		try {
			Method method = checker.getMethod(errorCode,dto_class);
			try {
				String checker_name = checker.getSimpleName();
				String bean_name = checker_name.substring(0,1).toLowerCase()+checker_name.substring(1);
				System.out.println(bean_name);
				return method.invoke(application.getBean(bean_name),dto);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			System.out.println("Method get Error");
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Object errorEmptyChecker(Object[] obj, Class[] cls, String[] errorField) {
		/**
		 * Developer Error
		 */
		Map<String,Boolean> field_name;
		if(obj.length != cls.length)
		{
			System.out.println("Error Code : obj miss class");
			return "Error Developer";
		}
		for(int i = 0 ; i<obj.length ; i++)
		{
			if(!cls[i].getSimpleName().equals(obj[i].getClass().getSimpleName()))
			{
				System.out.println("Error Code : class, obj miss match");
				return "Error Developer";
			}
		}
		field_name = new HashMap<String,Boolean>();
		for(int i = 0 ; i< errorField.length;i++)
		{
			String name = errorField[i].substring(0).toUpperCase()+errorField[i].substring(1);
			field_name.put(new String("get" + name),false);
		}
		for(int i = 0 ; i<cls.length;i++)
		{
			Field[] fields = cls[i].getFields();
			for(Field field : fields)
			{
				if(field.getName().equals())
				{
					
				}
			}
			Method[] methods = cls[i].getMethods();
			for(Method method : methods)
			{
				
			}
		}
		return null;
	}
}
