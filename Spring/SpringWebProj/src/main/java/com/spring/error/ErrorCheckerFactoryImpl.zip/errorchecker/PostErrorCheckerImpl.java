package com.spring.error.errorchecker;

import org.springframework.stereotype.Component;

@Component
public class PostErrorCheckerImpl implements PostErrorChecker{

}
